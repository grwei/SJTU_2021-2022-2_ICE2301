# Course project (ICE2301, 2022 Spring)

本-(2021-2022-2)-ICE2301-3-信号与系统（A类）

- [课程主页](https://grwei.github.io/SJTU_2021-2022-2_ICE2301/)
- [个人主页](https://grwei.github.io/)

[toc]

- [report](doc/project_危国锐_516021910080.pdf) (2022-06-05)

## Contents

## Data

- [original audio clip (simple 2)](https://musiclab.chromeexperiments.com/Song-Maker/song/6679651116384256)
- [original audio clip (simple)](https://musiclab.chromeexperiments.com/Song-Maker/song/5647271739260928)
- [original audio clip](https://musiclab.chromeexperiments.com/Song-Maker/song/5062339740565504)
- [original audio clip (repeated)](https://musiclab.chromeexperiments.com/Song-Maker/song/4885927180107776)

## Tool

- [MP3TAG: The universal tag editor](https://www.mp3tag.de/en/index.html)

## Contact Information

- Guorui Wei (危国锐)
- E-mail: 313017602@qq.com; weiguorui@sjtu.edu.cn
- Github: [https://github.com/grwei](https://github.com/grwei/)
